# xlhdnumpy

A package similar to Numpy.

## Features

- Create arrays
- Basic array operations (add, subtract, multiply, divide)
- Statistical functions (sum, mean,min,max,unique,median)

## Installation
pip install xlhdnumpy
## Usage
from xlhdnumpy import array

# Create an array
arr = array([1, 2, 3, 4, 5])
print(arr)
## License

This project is licensed under the MIT License - see the LICENSE file for details.
